package com.demo.cloudfunction.CloudFunctionDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudFunctionDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
